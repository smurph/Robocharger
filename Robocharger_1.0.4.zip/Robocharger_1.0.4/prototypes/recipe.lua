data:extend({
	{
		type = "recipe",
		name = "robocharger",
		enabled = "true",
		ingredients = 
		{
			{"steel-plate", 35},
			{"iron-gear-wheel", 30},
			{"advanced-circuit", 35},
			{"battery", 40}
		},
		result = "robocharger"
	}
})